
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class Menu_Supermercado {
    
    public void Supermercado(){
    
    int[] productosCliente1 = { 1, 2, 3, 4, 5, 6};
        Cliente client1 = new Cliente("Cliente_1", productosCliente1);
        
        int[] productosCliente2 = { 1, 2, 3, 4, 5,};
        Cliente cliente2 = new Cliente("Cliente_2", productosCliente2);
        
        Vendedor vendedor1 = new Vendedor(" Jennifer ");
        Vendedor vendedor2 = new Vendedor(" Cristian ");
        
        Thread hilo1 = new Thread(() -> {
            synchronized(vendedor1){
                vendedor1.procesarCompra(client1);
            }
        });
        
        Thread hilo2 = new Thread(() -> {
            synchronized(vendedor2){
                vendedor2.procesarCompra(cliente2);
            }
        });
        
        
        hilo1.start();
        hilo2.start();
    }
    
}
