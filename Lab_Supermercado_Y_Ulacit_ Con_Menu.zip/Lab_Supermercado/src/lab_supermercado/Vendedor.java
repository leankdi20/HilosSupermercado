
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class Vendedor {
    
    private String nombre;
    
    public Vendedor(String nombre){
        this.nombre= nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void procesarCompra(Cliente cliente){
        int tiempo = 0; 
        long start = System.currentTimeMillis();
        System.out.println("El vededor"+ nombre+" COMIENZA A PROCESAR LA COMPRA DEL CLIENTE " + cliente.getNombre() + " EN EL TIEMPO: "+ 0 + " seg.");
      
        
        for (int i = 0; i < cliente.getProductos().length; i++)
        {
            //tiempo += 1;
            long stop = 1000 + System.currentTimeMillis() - start;
            System.out.println("Procesando el producto " + cliente.getProductos()[i]+ " del cliente " + cliente.getNombre() + "->Tiempo: " + stop/1000 + "seg");
            try {
                 Thread.sleep((long) ((Math.random() * 2000) + 1000));
               // Thread.sleep(1500);
            } catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        long diferencia = System.currentTimeMillis() - start;
        System.out.println("El vendedor " + nombre + " HA TERMINADO DE PROCESAR " + cliente.getNombre()+ " EN EL TIEMPO "+ (diferencia/1000 )+ tiempo +" Seg.");
    }
    
}
