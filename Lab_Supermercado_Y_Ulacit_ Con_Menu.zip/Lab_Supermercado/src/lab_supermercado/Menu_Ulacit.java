package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class Menu_Ulacit {
     

    public void Ulacit() throws InterruptedException {
       

        for (int i = 1; i <= 10; i++)
        {
            class_U Hilo_1 = new class_U();
        class_L Hilo_2 = new class_L();
        class_A Hilo_3 = new class_A();
        class_C Hilo_4 = new class_C();
        class_I Hilo_5 = new class_I();
        class_T Hilo_6 = new class_T();

            Hilo_1.start();

            Hilo_1.sleep(300);

            Hilo_2.start();

            Hilo_2.sleep(400);

            Hilo_3.start();

            Hilo_3.sleep(500);

            Hilo_4.start();
            Hilo_4.sleep(600);

            Hilo_5.start();

            Hilo_5.sleep(700);

            Hilo_6.start();
            Hilo_6.sleep(800);

            System.out.println();
        }

    }

}
