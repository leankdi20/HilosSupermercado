
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class Cliente {
    private String nombre;
    private int[] productos;

    public Cliente(String nombre, int[] productos) {
        this.nombre = nombre;
        this.productos = productos;
    }
    

    public String getNombre() {
        return nombre;
    }
    
    public int[] getProductos(){
        return productos;
    }
    
}
