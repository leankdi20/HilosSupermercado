
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class class_T extends Thread{
    
    @Override
    public void run() {
        
        {
            System.out.print("T");
        }

    }
    
}
