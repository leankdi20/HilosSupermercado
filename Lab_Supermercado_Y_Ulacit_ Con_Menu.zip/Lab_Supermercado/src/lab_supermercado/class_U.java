
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class class_U extends Thread {

    

   

    @Override

    public void run() 
    {
        
           
            {
                System.out.print("U");
            }
        } 


    }

