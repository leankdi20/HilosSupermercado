package lab_supermercado;

import java.util.Scanner;

/**
 *
 * @author Leandro
 */
public class Lab_Supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {

        Scanner sc = new Scanner(System.in);

        int opcion = 0;
        boolean Salir = false;

        while (!Salir)
        {
            System.out.println("\nMENU");
            System.out.println("1. SUPERMERCADO");
            System.out.println("2. ULACIT");
            System.out.println("3. Salir");
            System.out.println("");

            System.out.print("Introduce una Opcion: ");
            System.out.println("");

            opcion = sc.nextInt();

            switch (opcion)
            {
                case 1:
                    System.out.println("MENU SUPERMERCADO AM. PM. .");
                    Menu_Supermercado Super = new Menu_Supermercado();
                    Super.Supermercado();

                    break;
                case 2:
                    System.out.println("MENU ULACIT");
                    Menu_Ulacit Ulacit = new Menu_Ulacit();
                    Ulacit.Ulacit();
                    break;
                case 3:
                    Salir = true;
                    break;

                default:
                    System.out.println("Opción inválida");
                    break;

            }
        }
    }
}


