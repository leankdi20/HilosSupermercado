
package lab_supermercado;

/**
 *
 * @author Leandro
 */
public class class_L extends Thread{
    
     

    @Override
    public void run() {
        
        {
            System.out.print("L");
        }

    }
    
}
